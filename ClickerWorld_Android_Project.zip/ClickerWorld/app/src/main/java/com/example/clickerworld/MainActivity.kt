package com.example.clickerworld

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query

private val Bg = Color(0xFF10131D)
private val Panel = Color(0xFF1B2130)
private val Accent = Color(0xFF7C6CFF)
private val Muted = Color(0xFF9AA4B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { ClickerWorldApp() }
    }
}

data class Player(val nickname: String, val clicks: Long)

@Composable
fun ClickerWorldApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    var signedIn by remember { mutableStateOf(false) }
    var guest by remember { mutableStateOf(false) }
    var nickname by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var clicks by remember { mutableLongStateOf(0L) }
    var message by remember { mutableStateOf("Подключаемся...") }
    var leaderboard by remember { mutableStateOf<List<Player>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var boardListener by remember { mutableStateOf<ListenerRegistration?>(null) }

    DisposableEffect(Unit) {
        val registration = db.collection("players")
            .orderBy("clicks", Query.Direction.DESCENDING)
            .limit(50)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    message = "Не удалось загрузить топ: проверьте Firebase"
                } else {
                    leaderboard = snapshot?.documents?.mapNotNull { doc ->
                        val name = doc.getString("nickname") ?: return@mapNotNull null
                        val count = doc.getLong("clicks") ?: 0L
                        Player(name, count)
                    } ?: emptyList()
                }
            }
        boardListener = registration
        onDispose { registration.remove() }
    }

    LaunchedEffect(Unit) {
        if (auth.currentUser == null) {
            auth.signInAnonymously()
                .addOnSuccessListener { loading = false; message = "Выберите ник или войдите как гость" }
                .addOnFailureListener { loading = false; message = "Ошибка входа. Настройте Firebase." }
        } else {
            loading = false
            val uid = auth.currentUser!!.uid
            db.collection("players").document(uid).get()
                .addOnSuccessListener { doc ->
                    if (doc.exists()) {
                        nickname = doc.getString("nickname") ?: ""
                        clicks = doc.getLong("clicks") ?: 0L
                        signedIn = true
                    } else {
                        message = "Выберите ник или войдите как гость"
                    }
                }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (loading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Accent)
                }
            } else if (!signedIn && !guest) {
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("CLICKER WORLD", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("Глобальный рейтинг кликов", color = Muted)
                    Spacer(Modifier.height(28.dp))
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        label = { Text("Придумай ник") },
                        singleLine = true,
                        supportingText = { Text("3–16 символов: буквы, цифры и _") }
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val clean = input.trim()
                            if (!clean.matches(Regex("^[A-Za-zА-Яа-яЁё0-9_]{3,16}$"))) {
                                message = "Ник должен быть длиной 3–16 символов"
                            } else {
                                val uid = auth.currentUser?.uid
                                if (uid == null) {
                                    message = "Нет соединения с Firebase"
                                } else {
                                    val normalized = clean.lowercase()
                                    val nickRef = db.collection("nicknames").document(normalized)
                                    val playerRef = db.collection("players").document(uid)
                                    db.runTransaction { tx ->
                                        val existing = tx.get(nickRef)
                                        if (existing.exists()) throw Exception("Этот ник уже занят")
                                        tx.set(nickRef, mapOf("uid" to uid, "nickname" to clean))
                                        tx.set(playerRef, mapOf("nickname" to clean, "clicks" to 0L))
                                    }.addOnSuccessListener {
                                        nickname = clean
                                        clicks = 0L
                                        signedIn = true
                                        message = ""
                                    }.addOnFailureListener { e ->
                                        message = if (e.message?.contains("занят") == true)
                                            "Этот ник уже занят. Выберите другой."
                                        else "Не удалось сохранить ник. Проверьте Firebase."
                                    }
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Играть с ником") }
                    TextButton(onClick = { guest = true }) { Text("Играть как гость") }
                    Text(message, color = Color(0xFFFFB86B), textAlign = TextAlign.Center)
                }
            } else {
                Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("CLICKER WORLD", fontWeight = FontWeight.Black, fontSize = 22.sp)
                            Text(if (guest) "Гостевой режим · не в рейтинге" else "Игрок: $nickname", color = Muted, fontSize = 12.sp)
                        }
                        Text("🌍 GLOBAL", color = Accent, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(22.dp))
                    Box(
                        Modifier.fillMaxWidth().weight(0.9f).background(Panel, RoundedCornerShape(28.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("ТВОИ КЛИКИ", color = Muted, letterSpacing = 2.sp)
                            Text(clicks.toString(), fontSize = 48.sp, fontWeight = FontWeight.Black)
                            Spacer(Modifier.height(22.dp))
                            Button(
                                onClick = {
                                    clicks += 1
                                    if (!guest) {
                                        val uid = auth.currentUser?.uid
                                        if (uid != null) {
                                            db.collection("players").document(uid)
                                                .update("clicks", FieldValue.increment(1))
                                        }
                                    }
                                },
                                modifier = Modifier.size(190.dp),
                                shape = CircleShape,
                                colors = ButtonDefaults.buttonColors(containerColor = Accent)
                            ) {
                                Text("CLICK\n+1", fontSize = 28.sp, lineHeight = 34.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.Black)
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(if (guest) "Гостевой результат не сохраняется" else "Каждое нажатие добавляет 1", color = Muted, fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("🏆 ГЛОБАЛЬНЫЙ ТОП · 50", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(
                        Modifier.weight(1f).fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(12.dp)
                    ) {
                        itemsIndexed(leaderboard) { index, player ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${index + 1}.", color = Accent, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
                                Text(player.nickname, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                                Text(player.clicks.toString(), color = Muted)
                            }
                            if (index != leaderboard.lastIndex) HorizontalDivider(color = Bg)
                        }
                        if (leaderboard.isEmpty()) item { Text("Пока нет игроков в рейтинге", color = Muted) }
                    }
                }
            }
        }
    }
}
